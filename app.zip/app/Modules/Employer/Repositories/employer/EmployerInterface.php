<?php

namespace Employer\Repositories\employer;


interface EmployerInterface
{

    public function store($request);


}
